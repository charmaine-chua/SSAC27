# NBA moneylines: longshot bias and the defense under-reaction

Analysis code and data for an SSAC research-paper abstract, "Deconstructing the Favorite-Longshot Bias in NBA Moneylines: The Market Prices Scoring, Not Stopping."

## What this tests

1. **Longshot bias.** Do underdogs win less often than their vig-free implied probability says, and does that depend on a team's "longshot type" (record-based strength vs. process-based strength, called divergence)?
2. **Which skill is under-priced.** The market's implied win probability and the realized win rate are each regressed on the same standardized team ratings (record, offense, defense). The gap between the two weights is the market's under-reaction to that rating.
3. **Is it tradable?** A walk-forward test estimates the effect only on earlier seasons, then bets the next season.

## Results (pooled 2007-08 to 2025-26)

| Test | Estimate | 95% CI | p |
|---|---|---|---|
| Longshot slope: calibration gap across deciles (pp) | +0.4 | (-1.3, +2.2) | .62 |
| Longshot x divergence interaction (return) | +0.04 | (-0.05, +0.14) | .36 |
| Offense under-reaction (pp per unit) | -0.5 | (-1.7, +0.5) | n/a |
| Defense under-reaction (pp per unit) | +0.9 | (-0.1, +2.0) | n/a |
| Defense minus offense under-reaction (pp per unit) | +1.5 | (+0.4, +2.6) | .012 (Holm .024) |
| Out-of-sample ROI, top-quintile signal bets (%) | -3.1 | (-5.7, -0.5) | n/a |

Pooled sample: 21,474 games; 15,958 have both teams with at least 20 prior games. `run_all.sh` regenerates every number, `results/table1.csv`, and `figures/Figure1_defense_underreaction.png`.

## Run it

```bash
pip install -r requirements.txt
bash run_all.sh
```

Takes a few minutes (bootstrap resampling). Seeds are fixed.

## Method notes

- **Vig removal:** Shin's method (two-outcome case, solved numerically per game), not proportional normalization.
- **No lookahead:** every team rating uses only that team's earlier games in the same season, with a 20-game minimum. Ratings are standardized within games-played buckets.
- **Ratings:** record = prior win%. Process = average of standardized prior scoring margin and Pythagorean expectation (exponent 13.91). Divergence = process minus record. Offense = prior points scored per game; defense = prior points allowed per game (sign-flipped so higher is better). These are not pace-adjusted.
- **Inference:** season fixed effects; standard errors and bootstrap CIs clustered by underdog team-season. Two hypotheses were tested (process beyond record; defense vs. offense) and Holm-corrected.
- **Bootstrap p-values** move a little between resampling runs for the defense-minus-offense difference (.004 to .012 across runs). Table 1 and the abstract use the more conservative .012, and Holm correction doubles it to .024.
- **Reading under-reaction:** realized weight minus market weight on a rating differential, in win-probability points per unit. Positive means the market under-weights it.

## Data

| Folder | Source | Coverage |
|---|---|---|
| `data/dotan/nba_adv_complete.csv` | Guy Dotan, UCLA MAS thesis repo (https://github.com/guydotan/ucla-thesis). NBA.com team box scores joined to Sportsbook Reviews Online moneylines. | 2007-08 to March 2020 |
| `data/wippa/nba_*_results_odds.csv` | wippa-studios/wippa-nba-data (https://github.com/wippa-studios/wippa-nba-data). Game results with closing decimal odds. | 2016-17 to 2018-19 (validation only), 2021-22 to 2025-26 (analysis) |

Moneylines for 2007-20 originate from the Sportsbook Reviews Online NBA archive (https://www.sportsbookreviewsonline.com/scoresoddsarchives/nba/nbaoddsarchives.htm). The archive does not say whether its lines are opening or closing lines.

Both repositories are MIT-licensed; their notices are in `LICENSES/`. The data files are unmodified copies.

## Known limitations

- The wippa data has no documented source. On the three seasons both sources cover (3,686 games), the scores match exactly and the home-win probabilities correlate at 0.998, but treat it as third-party.
- wippa dates run one day later than the archive's. The cross-check shifts them back; the analysis only uses dates for ordering and rest days within one source.
- No data for 2020-21; the archive ends in March 2020.
- In the 2021-26 window alone, the defense-minus-offense difference (+1.3) has a CI that includes zero, and offense and defense individually are noisy.
- Offense and defense are points per game, not possession-adjusted. No injury, lineup or roster-level (e.g., VORP) information is used.
- Ten wippa rows with invalid team names are dropped (see the log from `01_build_pooled.py`).
