"""Load Dotan (SBR odds + box scores, 2007-20) and wippa (2021-26) data, validate the wippa odds against SBR on shared seasons, pool."""
import numpy as np, pandas as pd, glob, json
from scipy.optimize import brentq
from scipy import stats
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; PROC = ROOT / "data" / "processed"; RES = ROOT / "results"; FIG = ROOT / "figures"
NAME2ABB = {'Atlanta Hawks': 'ATL', 'Boston Celtics': 'BOS', 'Brooklyn Nets': 'BKN', 'Charlotte Hornets': 'CHA', 'Chicago Bulls': 'CHI', 'Cleveland Cavaliers': 'CLE',
            'Dallas Mavericks': 'DAL', 'Denver Nuggets': 'DEN', 'Detroit Pistons': 'DET', 'Golden State Warriors': 'GSW', 'Houston Rockets': 'HOU', 'Indiana Pacers': 'IND',
            'Los Angeles Clippers': 'LAC', 'Los Angeles Lakers': 'LAL', 'Memphis Grizzlies': 'MEM', 'Miami Heat': 'MIA', 'Milwaukee Bucks': 'MIL', 'Minnesota Timberwolves': 'MIN',
            'New Orleans Pelicans': 'NOP', 'New York Knicks': 'NYK', 'Oklahoma City Thunder': 'OKC', 'Orlando Magic': 'ORL', 'Philadelphia 76ers': 'PHI', 'Phoenix Suns': 'PHX',
            'Portland Trail Blazers': 'POR', 'Sacramento Kings': 'SAC', 'San Antonio Spurs': 'SAS', 'Toronto Raptors': 'TOR', 'Utah Jazz': 'UTA', 'Washington Wizards': 'WAS'}

def shin(p1, p2):
    B = p1 + p2
    def q(z): return (np.sqrt(z * z + 4 * (1 - z) * np.array([p1, p2]) ** 2 / B) - z) / (2 * (1 - z))
    f = lambda z: q(z).sum() - 1
    if f(0) <= 0: return p1 / B, p2 / B
    r = q(brentq(f, 0, .999)); return r[0], r[1]
def ml2raw(ml): ml = np.asarray(ml, float); return np.where(ml < 0, -ml / (-ml + 100), 100 / (ml + 100))
def prof(ml, won): return np.where(won == 1, np.where(ml > 0, ml / 100, 100 / np.abs(ml)), -1.0)

# ---------- load ----------
d = pd.read_csv(DATA / 'dotan' / 'nba_adv_complete.csv'); d = d[(d.typeSeason == 'Regular Season') & (d['fgaTeam.own'] > 0)]
hm = d[d.locationGame == 'H'].dropna(subset=['teamML'])
Gs = pd.DataFrame({'date': pd.to_datetime(hm.dateGame), 'season': hm.slugSeason, 'home': hm.slugTeam, 'away': hm['slugOpponent.own'], 'hs': hm['ptsTeam.own'], 'as_': hm['ptsTeam.opp'],
                   'ph_raw': ml2raw(hm.teamML.values), 'pa_raw': ml2raw(hm.oppML.values), 'home_win': hm.isWin.astype(int).values, 'src': 'SBR'})
Gs['ret_h'] = prof(hm.teamML.values, Gs.home_win.values); Gs['ret_a'] = prof(hm.oppML.values, 1 - Gs.home_win.values)

W = pd.concat([pd.read_csv(f).assign(season=Path(f).stem.split('_')[1]) for f in sorted(glob.glob(str(DATA / 'wippa' / 'nba_*_results_odds.csv')))])
W = W[W['round'].isna()]
nb = len(W); W = W[W.home_team.isin(NAME2ABB) & W.away_team.isin(NAME2ABB)]; print('wippa regular rows', nb, 'dropped invalid team names', nb - len(W))
W = W.dropna(subset=['home_odds', 'away_odds', 'home_score', 'away_score']); W = W[(W.home_odds > 1) & (W.away_odds > 1)]
W['date'] = pd.to_datetime(W.date); W['home'] = W.home_team.map(NAME2ABB); W['away'] = W.away_team.map(NAME2ABB)
print('dups', W.duplicated(['date', 'home', 'away']).sum()); W = W.drop_duplicates(['date', 'home', 'away'])
Gw = pd.DataFrame({'date': W.date, 'season': W.season, 'home': W.home, 'away': W.away, 'hs': W.home_score.astype(float), 'as_': W.away_score.astype(float),
                   'ph_raw': 1 / W.home_odds, 'pa_raw': 1 / W.away_odds, 'home_win': (W.home_score > W.away_score).astype(int), 'src': 'wippa'})
Gw['ret_h'] = np.where(Gw.home_win == 1, W.home_odds - 1, -1.0); Gw['ret_a'] = np.where(Gw.home_win == 0, W.away_odds - 1, -1.0)

# ---------- cross-source validation on seasons 2016-17..2018-19 ----------
ov = Gw[Gw.season.isin(['2016-2017', '2017-2018', '2018-2019'])].copy()
ov['k'] = (ov.date - pd.Timedelta(days=1)).dt.strftime('%Y-%m-%d') + ov.home + ov.away
ss = Gs[Gs.season.isin(['2016-17', '2017-18', '2018-19'])].copy(); ss['k'] = ss.date.dt.strftime('%Y-%m-%d') + ss.home + ss.away
m = ov.merge(ss, on='k', suffixes=('_w', '_s'))
pw = m.ph_raw_w / (m.ph_raw_w + m.pa_raw_w); ps = m.ph_raw_s / (m.ph_raw_s + m.pa_raw_s)
print('overlap games matched: %d of wippa %d / SBR %d' % (len(m), len(ov), len(ss)))
print('corr home win prob (prop-devig) wippa vs SBR: %.4f ; mean abs diff %.4f ; scores agree %.4f ; mean overround wippa %.4f SBR %.4f' %
      (np.corrcoef(pw, ps)[0, 1], np.abs(pw - ps).mean(), ((m.hs_w == m.hs_s) & (m.as__w == m.as__s)).mean(), (m.ph_raw_w + m.pa_raw_w - 1).mean(), (m.ph_raw_s + m.pa_raw_s - 1).mean()))

# ---------- pooled sample: SBR 2007-08..2019-20  +  wippa 2021-22..2025-26 ----------
Gp = pd.concat([Gs, Gw[Gw.season >= '2021-2022']], ignore_index=True)
Gp['era'] = np.where(Gp.src == 'SBR', 'SBR 2007-20', 'Post-2020')
Gp.to_pickle(PROC / 'pooled_raw.pkl')
print(Gp.groupby('src').size().to_dict(), 'total', len(Gp))
