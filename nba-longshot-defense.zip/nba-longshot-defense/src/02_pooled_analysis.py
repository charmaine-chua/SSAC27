"""Pooled tests: longshot calibration/return, divergence interaction, market-vs-realized weights (process, offense/defense), era splits."""
import numpy as np, pandas as pd, json
from scipy import stats
from scipy.optimize import brentq
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; PROC = ROOT / "data" / "processed"; RES = ROOT / "results"; FIG = ROOT / "figures"
rng = np.random.default_rng(31)
G = pd.read_pickle(PROC / 'pooled_raw.pkl')
G['season_id'] = G.src + '_' + G.season.astype(str)

def shin(p1, p2):
    B = p1 + p2
    def q(z): return (np.sqrt(z * z + 4 * (1 - z) * np.array([p1, p2]) ** 2 / B) - z) / (2 * (1 - z))
    f = lambda z: q(z).sum() - 1
    if f(0) <= 0: return p1 / B, p2 / B
    r = q(brentq(f, 0, .999)); return r[0], r[1]

# ---------- team-game table with prior-only stats ----------
G = G.sort_values('date').reset_index(drop=True)
H = pd.DataFrame({'gid': G.index, 'date': G.date, 'sid': G.season_id, 'team': G.home, 'pf': G.hs, 'pa': G.as_, 'loc': 1})
A = pd.DataFrame({'gid': G.index, 'date': G.date, 'sid': G.season_id, 'team': G.away, 'pf': G.as_, 'pa': G.hs, 'loc': 0})
T = pd.concat([H, A]).sort_values(['sid', 'team', 'date', 'gid']).reset_index(drop=True)
T['win'] = (T.pf > T.pa).astype(int); T['mar'] = T.pf - T.pa
g = T.groupby(['sid', 'team']); T['n'] = g.cumcount()
for c in ['win', 'pf', 'pa', 'mar']: T['c_' + c] = g[c].cumsum() - T[c]
T['rest'] = g['date'].diff().dt.days.fillna(7).clip(upper=7)
T['wp'] = T.c_win / T.n; T['mov'] = T.c_mar / T.n; T['off'] = T.c_pf / T.n; T['dfn'] = T.c_pa / T.n
T['py'] = T.c_pf ** 13.91 / (T.c_pf ** 13.91 + T.c_pa ** 13.91)
ok = T.n >= 20; T['bk'] = pd.cut(T.n, [-1, 19, 29, 39, 49, 59, 100], labels=False)
def zb(s): return s.groupby(T.bk).transform(lambda x: (x - x[ok[x.index]].mean()) / x[ok[x.index]].std())
T['zrec'] = zb(T.wp); T['zoff'] = zb(T.off); T['zdef'] = -zb(T.dfn)
T['zproc'] = zb(pd.concat([zb(T.mov), zb(T.py)], axis=1).mean(axis=1)); T['div'] = zb(T.zproc - T.zrec)
h = T[T['loc'] == 1].set_index('gid'); a = T[T['loc'] == 0].set_index('gid')
cols = ['n', 'zrec', 'zproc', 'div', 'rest', 'zoff', 'zdef']
G = G.join(h[cols].add_suffix('_h')).join(a[cols].add_suffix('_a'))
sh = np.array([shin(x, y) for x, y in zip(G.ph_raw, G.pa_raw)]); G['ps_h'], G['ps_a'] = sh[:, 0], sh[:, 1]
G = G[np.abs(G.ps_h - G.ps_a) > 1e-9].copy(); dh = (G.ps_h < G.ps_a)
pk = lambda x, y: np.where(dh, G[x], G[y]); pf = lambda x, y: np.where(dh, G[y], G[x])
O = pd.DataFrame({'era': G.era.values, 'season': G.season_id.values, 'dog_home': dh.astype(int).values, 'p_dog': pk('ps_h', 'ps_a'), 'dog_won': np.where(dh, G.home_win, 1 - G.home_win),
                  'ret': pk('ret_h', 'ret_a'), 'ret_fav': pf('ret_h', 'ret_a'), 'p_fav': pf('ps_h', 'ps_a'), 'n_dog': pk('n_h', 'n_a'), 'n_fav': pf('n_h', 'n_a'),
                  'div_dog': pk('div_h', 'div_a'), 'div_fav': pf('div_h', 'div_a'), 'zrec_dog': pk('zrec_h', 'zrec_a'), 'zrec_fav': pf('zrec_h', 'zrec_a'),
                  'zoff_dog': pk('zoff_h', 'zoff_a'), 'zoff_fav': pf('zoff_h', 'zoff_a'), 'zdef_dog': pk('zdef_h', 'zdef_a'), 'zdef_fav': pf('zdef_h', 'zdef_a'),
                  'rest_dog': pk('rest_h', 'rest_a'), 'rest_fav': pf('rest_h', 'rest_a'),
                  'tm': np.where(dh, G.home, G.away) + '_' + G.season_id.values, 'overround': (G.ph_raw + G.pa_raw - 1).values})
O.to_pickle(PROC / 'pooled_O.pkl')
S = O[(O.n_dog >= 20) & (O.n_fav >= 20)].reset_index(drop=True)
S['rd'] = S.rest_dog - S.rest_fav; S['ddiv'] = S.div_dog - S.div_fav; S['dzrec'] = S.zrec_dog - S.zrec_fav
S['doff'] = S.zoff_dog - S.zoff_fav; S['ddef'] = S.zdef_dog - S.zdef_fav; S['gap'] = S.dog_won - S.p_dog
print('pooled games %d, analysis sample %d, seasons %d, clusters %d' % (len(O), len(S), S.season.nunique(), S.tm.nunique()))
print(S.groupby('era').size().to_dict(), '| mean overround by era:', O.groupby('era').overround.mean().round(4).to_dict())

def ols(y, X, cl):
    X = X.loc[:, (X.std() > 0) | (X.columns == 'c')]; Xv = X.values.astype(float); yv = np.asarray(y, float)
    XtXi = np.linalg.inv(Xv.T @ Xv); b = XtXi @ Xv.T @ yv; e = yv - Xv @ b
    codes = pd.factorize(cl)[0]; Gc = codes.max() + 1; n, k = Xv.shape
    gs = np.zeros((Gc, k)); np.add.at(gs, codes, Xv * e[:, None]); V = XtXi @ (gs.T @ gs) @ XtXi * (Gc / (Gc - 1)) * ((n - 1) / (n - k))
    se = np.sqrt(np.clip(np.diag(V), 0, None)); return pd.DataFrame({'b': b, 'se': se, 'p': 2 * stats.t.sf(np.abs(b / se), Gc - 1)}, index=X.columns)
R = {'n_games': len(O), 'n_sample': len(S), 'seasons': int(S.season.nunique()), 'clusters': int(S.tm.nunique())}

# ----- A. pooled FLB (all games) -----
A_ = O.copy(); A_['LS'] = 1 - pd.qcut(A_.p_dog, 10, labels=False) / 9.0; A_['gap'] = A_.dog_won - A_.p_dog
fe = pd.get_dummies(A_.season, drop_first=True).astype(float)
X = pd.concat([pd.Series(1.0, index=A_.index, name='c'), A_[['LS']], fe], axis=1)
r = ols(A_.gap, X, A_.tm); R['flb_gap'] = r.loc['LS'].to_dict(); r2 = ols(A_.ret, X, A_.tm); R['flb_ret'] = r2.loc['LS'].to_dict()
R['mean_roi'] = float(A_.ret.mean()); R['mean_overround'] = float(A_.overround.mean())
for e_ in A_.era.unique():
    m = A_.era == e_; Xe = X[m]; re = ols(A_.gap[m], Xe, A_.tm[m]); R['flb_gap_' + e_] = re.loc['LS'].to_dict(); R['roi_' + e_] = float(A_.ret[m].mean()); R['over_' + e_] = float(A_.overround[m].mean())
print('A. pooled FLB gap slope %.4f (se %.4f, p %.3f); return slope %.4f (p %.3f); mean ROI %.4f vs overround %.4f' % (R['flb_gap']['b'], R['flb_gap']['se'], R['flb_gap']['p'], R['flb_ret']['b'], R['flb_ret']['p'], R['mean_roi'], R['mean_overround']))
for e_ in A_.era.unique(): print('   ', e_, 'gap slope %.4f p %.3f ROI %.4f overround %.4f' % (R['flb_gap_' + e_]['b'], R['flb_gap_' + e_]['p'], R['roi_' + e_], R['over_' + e_]))

# ----- B. interaction pooled -----
S['LS'] = 1 - pd.qcut(S.p_dog, 10, labels=False) / 9.0; S['dv'] = S.div_dog; S['LSdv'] = S.LS * S.dv
fe = pd.get_dummies(S.season, drop_first=True).astype(float)
base = pd.concat([pd.Series(1.0, index=S.index, name='c'), S[['dog_home', 'rd', 'div_fav']].astype(float), fe], axis=1)
r = ols(S.ret, pd.concat([base, S[['LS', 'dv', 'LSdv']]], axis=1), S.tm); R['interaction'] = r.loc['LSdv'].to_dict(); R['dv_main'] = r.loc['dv'].to_dict()
print('B. pooled interaction b=%.3f se=%.3f p=%.3f | CI [%.3f, %.3f]' % (r.loc['LSdv', 'b'], r.loc['LSdv', 'se'], r.loc['LSdv', 'p'], r.loc['LSdv', 'b'] - 1.96 * r.loc['LSdv', 'se'], r.loc['LSdv', 'b'] + 1.96 * r.loc['LSdv', 'se']))

# ----- C/D. mechanism: market vs realized weights, with cluster bootstrap -----
fe = pd.get_dummies(S.season, drop_first=True).astype(float)
def design(extra):
    return pd.concat([pd.Series(1.0, index=S.index, name='c'), S[['dog_home', 'rd'] + extra].astype(float), fe], axis=1)
def weights(extra, idx=None, boot=0):
    X = design(extra); X = X.loc[:, (X.std() > 0) | (X.columns == 'c')]; names = list(X.columns); Xv = X.values
    ii = [names.index(c) for c in extra]; res = {}
    def fit(idx):
        bm = np.linalg.lstsq(Xv[idx], S.p_dog.values[idx], rcond=None)[0]; bo = np.linalg.lstsq(Xv[idx], S.dog_won.values[idx], rcond=None)[0]
        return np.array([[bm[i], bo[i]] for i in ii])
    full = fit(np.arange(len(S))); out = [fit(np.concatenate([by[keys[k]] for k in rng.integers(0, len(keys), len(keys))])) for _ in range(boot)] if boot else None
    return full, (np.array(out) if boot else None)
by = S.groupby('tm').indices; keys = list(by)

specs = {'H1_process_beyond_record': ['dzrec', 'ddiv'], 'H2_off_def_beyond_record': ['dzrec', 'doff', 'ddef'], 'offdef_raw': ['doff', 'ddef']}
for nm, ex in specs.items():
    full, bt = weights(ex, boot=1000); R[nm] = {}
    print('\n', nm)
    for j, c in enumerate(ex):
        mk, oc = full[j]; diff = oc - mk; bd = bt[:, j, 1] - bt[:, j, 0]; ratio = bt[:, j, 0] / bt[:, j, 1]
        p_b = 2 * min((bd <= 0).mean(), (bd >= 0).mean())
        R[nm][c] = {'market': mk, 'outcome': oc, 'diff': diff, 'diff_ci': list(np.percentile(bd, [2.5, 97.5])), 'ratio': mk / oc, 'ratio_ci': list(np.percentile(ratio, [2.5, 97.5])), 'p_boot': p_b}
        print('  %-6s market %.4f outcome %.4f diff %+.4f CI [%+.4f, %+.4f] ratio %.2f [%.2f, %.2f] boot p=%.3f' % (c, mk, oc, diff, *np.percentile(bd, [2.5, 97.5]), mk / oc, *np.percentile(ratio, [2.5, 97.5]), p_b))
    if nm == 'H2_off_def_beyond_record' or nm == 'offdef_raw':
        jo, jd = ex.index('doff'), ex.index('ddef'); dd = (bt[:, jd, 1] - bt[:, jd, 0]) - (bt[:, jo, 1] - bt[:, jo, 0])
        R[nm]['def_minus_off_underreaction'] = {'point': float((full[jd, 1] - full[jd, 0]) - (full[jo, 1] - full[jo, 0])), 'ci': list(np.percentile(dd, [2.5, 97.5])), 'p_boot': float(2 * min((dd <= 0).mean(), (dd >= 0).mean()))}
        print('  DEF minus OFF under-reaction: %+.4f CI [%+.4f, %+.4f] boot p=%.3f' % (R[nm]['def_minus_off_underreaction']['point'], *R[nm]['def_minus_off_underreaction']['ci'], R[nm]['def_minus_off_underreaction']['p_boot']))

# ----- era splits for the offense/defense decomposition (descriptive) -----
for e_ in ['SBR 2007-20', 'Post-2020']:
    m = (S.era == e_).values; idx0 = np.where(m)[0]
    X = design(['doff', 'ddef']); X = X.loc[:, (X.std() > 0) | (X.columns == 'c')]; names = list(X.columns); Xv = X.values
    def fit(idx): return np.array([[np.linalg.lstsq(Xv[idx], S.p_dog.values[idx], rcond=None)[0][names.index(c)], np.linalg.lstsq(Xv[idx], S.dog_won.values[idx], rcond=None)[0][names.index(c)]] for c in ['doff', 'ddef']])
    f0 = fit(idx0); bys = pd.Series(idx0).groupby(S.tm.values[idx0]).apply(lambda s: s.values).to_dict(); ks = list(bys)
    bt = np.array([fit(np.concatenate([bys[ks[k]] for k in rng.integers(0, len(ks), len(ks))])) for _ in range(500)])
    dd = (bt[:, 1, 1] - bt[:, 1, 0]) - (bt[:, 0, 1] - bt[:, 0, 0]); dp = (f0[1, 1] - f0[1, 0]) - (f0[0, 1] - f0[0, 0])
    R['era_' + e_] = {'off': f0[0].tolist(), 'def': f0[1].tolist(), 'def_minus_off': float(dp), 'ci': list(np.percentile(dd, [2.5, 97.5])), 'n': int(m.sum())}
    print('era', e_, 'n', m.sum(), 'offense mkt/out %.4f/%.4f  defense mkt/out %.4f/%.4f  def-off under-reaction %+.4f CI [%+.4f, %+.4f]' % (*f0[0], *f0[1], dp, *np.percentile(dd, [2.5, 97.5])))
json.dump(R, open(RES / 'results_pooled.json', 'w'), indent=1, default=float)
S.to_pickle(PROC / 'pooled_S.pkl')
