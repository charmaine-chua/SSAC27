"""Bootstrap offense/defense under-reaction by period and draw Figure 1."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; PROC = ROOT / "data" / "processed"; RES = ROOT / "results"; FIG = ROOT / "figures"
import numpy as np, pandas as pd, json, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
rng=np.random.default_rng(404)
S=pd.read_pickle(PROC / 'pooled_S.pkl')
fe=pd.get_dummies(S.season,drop_first=True).astype(float)
X=pd.concat([pd.Series(1.0,index=S.index,name='c'),S[['dog_home','rd','doff','ddef']].astype(float),fe],axis=1)
def prep(mask):
    Xm=X[mask]; Xm=Xm.loc[:,(Xm.std()>0)|(Xm.columns=='c')]; return Xm.values,list(Xm.columns)
res={}
for nm,mask in [('Pooled 2007-08 to 2025-26',np.ones(len(S),bool)),('2007-08 to 2019-20',(S.era=='SBR 2007-20').values),('2021-22 to 2025-26',(S.era=='Post-2020').values)]:
    Xv,cols=prep(mask); y_m=S.p_dog.values[mask]; y_o=S.dog_won.values[mask]; tm=S.tm.values[mask]
    io,idf=cols.index('doff'),cols.index('ddef')
    def fit(idx):
        bm=np.linalg.lstsq(Xv[idx],y_m[idx],rcond=None)[0]; bo=np.linalg.lstsq(Xv[idx],y_o[idx],rcond=None)[0]
        return np.array([bo[io]-bm[io],bo[idf]-bm[idf]])
    f0=fit(np.arange(len(y_m))); by=pd.Series(np.arange(len(tm))).groupby(tm).apply(lambda s:s.values).to_dict(); ks=list(by)
    bt=np.array([fit(np.concatenate([by[ks[k]] for k in rng.integers(0,len(ks),len(ks))])) for _ in range(1000)])
    dd=bt[:,1]-bt[:,0]
    res[nm]={'n':int(mask.sum()),'off':[100*f0[0],*(100*np.percentile(bt[:,0],[2.5,97.5]))],'def':[100*f0[1],*(100*np.percentile(bt[:,1],[2.5,97.5]))],'diff':[100*(f0[1]-f0[0]),*(100*np.percentile(dd,[2.5,97.5]))],'p_diff':float(2*min((dd<=0).mean(),(dd>=0).mean()))}
    print(nm,res[nm])
json.dump(res,open(RES / 'results_fig2.json','w'),indent=1)

# ---- figure: defense-minus-offense under-reaction by period ----
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9})
fig,ax=plt.subplots(figsize=(6.4,2.9),dpi=300)
rows=['2021-22 to 2025-26','2007-08 to 2019-20','Pooled 2007-08 to 2025-26']
for i,r in enumerate(rows):
    v,lo,hi=res[r]['diff']; pooled=r.startswith('Pooled')
    ax.plot([lo,hi],[i,i],color='#2a78d6',lw=2.2 if pooled else 1.6,solid_capstyle='round',zorder=2)
    ax.plot(v,i,'o',color='#2a78d6',ms=8 if pooled else 6.5,mec='#fcfcfb',mew=1,zorder=3)
    ax.annotate(f"{v:+.1f}  [{lo:+.1f}, {hi:+.1f}]",(hi,i),xytext=(8,0),textcoords='offset points',va='center',fontsize=8,color='#0b0b0b')
ax.axvline(0,color='#52514e',lw=0.8,zorder=1)
ax.set_yticks(range(3)); ax.set_yticklabels([f"{r}\n(n = {res[r]['n']:,} games)" for r in rows],fontsize=8)
ax.set_xlim(-2,6.4); ax.set_ylim(-0.6,2.6)
ax.set_xlabel('Defense minus offense under-reaction\n(win-probability points per unit of rating differential)')
ax.set_title('Defense is priced less fully than offense',loc='left',fontsize=9.5)
ax.grid(axis='x',color='#e6e5e0',lw=0.6); ax.set_axisbelow(True)
for s_ in ['top','right']: ax.spines[s_].set_visible(False)
for s_ in ['left','bottom']: ax.spines[s_].set_color('#b9b8b1')
fig.text(0.01,0.005,'Dots: estimates; lines: 95% CIs (bootstrap clustered by underdog team-season). Positive = defense under-priced relative to offense.',fontsize=6.3,color='#52514e')
fig.tight_layout(rect=(0,0.035,1,1)); fig.savefig(FIG / 'Figure1_defense_underreaction.png',facecolor='#fcfcfb')
