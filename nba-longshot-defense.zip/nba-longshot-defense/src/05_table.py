"""Assemble Table 1 (summary of tests) from the result files."""
import json, csv
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; PROC = ROOT / "data" / "processed"; RES = ROOT / "results"; FIG = ROOT / "figures"


A=json.load(open(RES/'results_pooled.json')); F=json.load(open(RES/'results_fig2.json')); W=json.load(open(RES/'results_wf.json'))
pooled=F['Pooled 2007-08 to 2025-26']; H2=A['offdef_raw']['def_minus_off_underreaction']
fl=A['flb_gap']; it=A['interaction']
rows=[('Longshot slope: calibration gap across deciles (pp)',100*fl['b'],100*(fl['b']-1.96*fl['se']),100*(fl['b']+1.96*fl['se']),fl['p']),
('Longshot x divergence interaction (return)',it['b'],it['b']-1.96*it['se'],it['b']+1.96*it['se'],it['p']),
('Offense under-reaction (pp per unit)',*pooled['off'],None),
('Defense under-reaction (pp per unit)',*pooled['def'],None),
('Defense minus offense under-reaction (pp per unit)',*pooled['diff'],H2['p_boot']),
('Out-of-sample ROI, top-quintile signal bets (%)',100*W['bets']['top 20% |signal|'][1],100*W['bets']['top 20% |signal|'][2],100*W['bets']['top 20% |signal|'][3],None)]
with open(RES/'table1.csv','w',newline='') as f:
    w=csv.writer(f); w.writerow(['test','estimate','ci_low','ci_high','p'])
    for r in rows: w.writerow([r[0]]+[None if x is None else round(x,3) for x in r[1:]])
print(open(RES/'table1.csv').read())
