"""Walk-forward out-of-sample test: estimate defense/offense under-reaction on prior seasons, bet the next season."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"; PROC = ROOT / "data" / "processed"; RES = ROOT / "results"; FIG = ROOT / "figures"
import numpy as np, pandas as pd, json
rng=np.random.default_rng(8)
S=pd.read_pickle(PROC / 'pooled_S.pkl')
# chronological season order
yr=S.season.str.extract(r'(\d{4})')[0].astype(int); S['yr']=yr
order=sorted(S.yr.unique()); print(order)
S['sig']=np.nan
for y in order[5:]:
    tr=S[S.yr<y]; te=S.yr==y
    X=np.c_[np.ones(len(tr)),tr.doff,tr.ddef]; b=np.linalg.lstsq(X,tr.gap.values,rcond=None)[0]
    S.loc[te,'sig']=b[1]*S.loc[te,'doff']+b[2]*S.loc[te,'ddef']      # intercept excluded: edge from the signal only
    S.loc[te,'b_off']=b[1]; S.loc[te,'b_def']=b[2]
T=S.dropna(subset=['sig']).copy(); print('out-of-sample games',len(T),'seasons',T.yr.nunique())
print('mean |predicted edge| %.4f pp ; sd %.4f'%(100*T.sig.abs().mean(),100*T.sig.std()))
# (1) realized dog gap by signal quintile
T['q']=pd.qcut(T.sig,5,labels=False)+1
tbl=T.groupby('q').agg(n=('gap','size'),pred_pp=('sig',lambda s:100*s.mean()),real_gap_pp=('gap',lambda s:100*s.mean()))
def bci(df,col,B=1500):
    gi=df.groupby('tm')[col].agg(['sum','count']); s,c=gi['sum'].values,gi['count'].values
    bs=[s[k].sum()/c[k].sum() for k in (rng.integers(0,len(s),len(s)) for _ in range(B))]; return np.percentile(bs,[2.5,97.5])
tbl['lo']=[100*bci(T[T.q==q],'gap')[0] for q in tbl.index]; tbl['hi']=[100*bci(T[T.q==q],'gap')[1] for q in tbl.index]
print(tbl.round(2).to_string())
# slope: realized gap on predicted, cluster bootstrap
def slope(df): 
    x=df.sig.values; y=df.gap.values; return np.cov(x,y)[0,1]/np.var(x,ddof=1)
by=T.groupby('tm').indices; keys=list(by)
sl=[slope(T.iloc[np.concatenate([by[keys[k]] for k in rng.integers(0,len(keys),len(keys))])]) for _ in range(1000)]
print('out-of-sample calibration slope of realized gap on predicted: %.2f CI %s (1 = perfect)'%(slope(T),np.percentile(sl,[2.5,97.5]).round(2)))
# (2) betting: bet side with positive predicted edge
T['bet_ret']=np.where(T.sig>0,T.ret,T.ret_fav)
T['bet_edge_pred']=T.sig.abs()
out={}
for nm,mask in [('all games',np.ones(len(T),bool)),('top 20% |signal|',T.sig.abs()>=T.sig.abs().quantile(.8)),('top 10% |signal|',T.sig.abs()>=T.sig.abs().quantile(.9))]:
    d=T[mask]; ci=bci(d,'bet_ret'); out[nm]=(len(d),d.bet_ret.mean(),ci)
    print('%-18s n=%5d ROI %+.2f%%  CI [%+.1f, %+.1f]  | baseline avg ROI of both sides ~ -%.1f%%'%(nm,len(d),100*d.bet_ret.mean(),100*ci[0],100*ci[1],100*(T.overround.mean()/2)))
# reference: random-side betting ROI in same games
ref=np.where(rng.random(len(T))<.5,T.ret,T.ret_fav).mean(); print('random-side ROI same games %+.2f%%'%(100*ref))
print('mean overround OOS %.4f'%T.overround.mean())
tbl.reset_index().to_csv(RES / 'wf_quintiles.csv',index=False)
json.dump({'n':len(T),'quint':tbl.round(4).reset_index().to_dict('records'),'slope':[slope(T),*np.percentile(sl,[2.5,97.5])],'bets':{k:[v[0],v[1],*v[2]] for k,v in out.items()}},open(RES / 'results_wf.json','w'),indent=1,default=float)
