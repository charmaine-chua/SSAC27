#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 src/01_build_pooled.py
python3 src/02_pooled_analysis.py
python3 src/03_walk_forward.py
python3 src/04_figure.py
python3 src/05_table.py
